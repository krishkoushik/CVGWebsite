#include <assert.h>

#define DEBUG
#undef NDEBUG

int main(void)
{
    assert(0);
    return 0;
}

