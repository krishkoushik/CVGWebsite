int main(void)
{
    char *s = "hello World!";
    *s = 'H';
    return 0;
}
