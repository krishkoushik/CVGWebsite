int t[5000][5000];
int main()
{
    return t[100][100];
}

