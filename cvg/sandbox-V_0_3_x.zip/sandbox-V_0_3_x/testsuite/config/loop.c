int incr(int i)
{
    return i + 1;
}

int main(int argc, char * argv[])
{
    int i = 0;
    while (1)
    {
        i = incr(i);
    }
    return 0;
}

