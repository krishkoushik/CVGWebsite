#include <stdlib.h>
#include <unistd.h>

int main(void)
{
    vfork();
    return 0;
}
